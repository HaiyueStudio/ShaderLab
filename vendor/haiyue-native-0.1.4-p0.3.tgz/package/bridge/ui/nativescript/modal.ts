import { Color, GridLayout, Page, ScrollView, type LayoutBase, type View } from '@nativescript/core';
/** A native modal window with a centered, scrollable card. The caller owns all
 * listeners through its normal cleanup scope and controls dismissal. */
export function createModalSurface(content: LayoutBase, listen:(view:View,name:string,callback:(event:any)=>void)=>unknown,
  cancel:()=>void, maxHeight:()=>number=()=>Infinity, selection?: {anchor:View; presentation?:'auto'|'popover'|'sheet'}) {
  const page=new Page(),overlay=new GridLayout(),card=new ScrollView();
  page.actionBarHidden=true;page.content=overlay;page.backgroundColor=new Color('rgba(0,0,0,0.72)');overlay.padding=16;
  card.content=content;card.width='100%';card.maxWidth=460;card.horizontalAlignment='center';card.verticalAlignment='middle';overlay.addChild(card);
  let previous=0,timer:ReturnType<typeof setTimeout>|undefined,disposed=false;
  const position=()=>{
    if(disposed)return;
    if(selection) {
      const bounds=overlay.getActualSize(),anchor=selection.anchor.getLocationInWindow(),origin=overlay.getLocationInWindow();
      if(bounds.width<=32||bounds.height<=64)return;
      const wide=bounds.width>=600, popover=selection.presentation==='popover'||(selection.presentation!=='sheet'&&wide);
      page.backgroundColor=new Color('rgba(0,0,0,0.32)');
      if(popover&&anchor&&origin) {
        const width=Math.min(320,Math.max(220,selection.anchor.getActualSize().width),bounds.width-32);
        card.width=width;card.maxWidth=width;card.horizontalAlignment='left';card.verticalAlignment='top';
        const desired=content.getActualSize().height||Math.min(400,bounds.height/2),height=Math.min(desired,400,bounds.height-32);
        card.marginLeft=Math.max(0,Math.min(bounds.width-width-32,anchor.x-origin.x-16));
        const below=anchor.y-origin.y+selection.anchor.getActualSize().height+6;
        card.marginTop=Math.max(0,Math.min(bounds.height-height-32,below+height>bounds.height-16?anchor.y-origin.y-height-6:below)-16);
        card.maxHeight=height;
      } else {
        card.width='100%';card.maxWidth=590;card.horizontalAlignment='center';card.verticalAlignment='bottom';card.marginLeft=0;card.marginTop=0;card.maxHeight=Math.max(44,bounds.height-64);
      }
      return;
    }
    const height=Math.min(maxHeight(),Math.max(44,overlay.getActualSize().height-32));
    if(height!==previous){previous=height;card.maxHeight=height;}
  };
  // NativeScript raises layoutChanged inside its layout pass. Mutating child
  // geometry there can be overwritten by the parent; commit on the next turn.
  const schedule=()=>{if(disposed||timer!==undefined)return;timer=setTimeout(()=>{timer=undefined;position();},0);};
  const dispose=()=>{disposed=true;if(timer!==undefined)clearTimeout(timer);timer=undefined;};
  listen(overlay,'layoutChanged',selection?schedule:position);
  if(selection)listen(page,'shownModally',schedule);
  listen(page,'unloaded',()=>{if(timer!==undefined)clearTimeout(timer);timer=undefined;});
  listen(overlay,'tap',event=>{
    const x=event.getX?.(),y=event.getY?.(),position=card.getLocationRelativeTo(overlay),size=card.getActualSize();
    if(position&&Number.isFinite(x)&&Number.isFinite(y)&&(x<position.x||x>position.x+size.width||y<position.y||y>position.y+size.height))cancel();
  });
  return {page,card,dispose};
}
