// Compatibility entry: still includes the optional Engine adapter.
export * from './bridge/engine';
export { NativeDeviceMotion, type NativeDeviceMotionOptions, type NativeMotionSample, type MotionScreenRotation } from './bridge/motion/device-motion';
export { NativeHaptics, type NativeImpact } from './bridge/feedback/haptics';
export { NativePcmAudioBank, type NativePcmSound, type NativePcmPlay } from './bridge/audio/pcm-bank';
export { NativeOrientationController } from './bridge/display/orientation';
export { type OrientationPolicy } from './bridge/display/orientation-policy';
export { NativeSettingsStorage } from './bridge/storage/settings-storage';
export { installNativeSaveRuntime } from './bridge/storage/clone-runtime';
export { readNativeBytes } from './bridge/files/read-bytes';
export { savePhoto } from './bridge/media/save-photo';
export { NativeEngineLaunchPage } from './bridge/branding/launch-page';
export { NativeEngineSplash, type NativeEngineSplashOptions } from './bridge/branding/engine-splash';
export { shareContent, canShareContent, ShareError, type ShareContent, type ShareImage, type ShareResult, type ShareErrorCode } from './bridge/share/share-content';
